import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'models/product.dart';
import 'services/api_service.dart';
import 'cubits/cart_cubit.dart'; // Náš nový Cubit

void main() {
  runApp(
    // Poskytneme CartCubit celé aplikaci
    BlocProvider(create: (context) => CartCubit(), child: const PosApp()),
  );
}

class PosApp extends StatelessWidget {
  const PosApp({super.key});

  void _showPendingOrdersDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (ctx) {
        return AlertDialog(
          title: const Text('Čekající rezervace'),
          content: SizedBox(
            width: double.maxFinite,
            height: 400,
            child: FutureBuilder<List<dynamic>>(
              future: apiService.fetchPendingOrders(),
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(child: CircularProgressIndicator());
                } else if (snapshot.hasError) {
                  return Text('Chyba: ${snapshot.error}');
                } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
                  return const Center(child: Text('Žádné čekající rezervace.'));
                }

                final orders = snapshot.data!;
                return ListView.builder(
                  itemCount: orders.length,
                  itemBuilder: (context, index) {
                    final order = orders[index];
                    return ListTile(
                      leading: const Icon(Icons.person),
                      title: Text(
                        '${order['customer']} - ${order['total_amount']} Kč',
                      ),
                      subtitle: Text(
                        'Vyzvednutí: ${order['pickup_date'] ?? 'Nezadáno'}',
                      ),
                      trailing: IconButton(
                        icon: const Icon(
                          Icons.check_circle,
                          color: Colors.green,
                        ),
                        onPressed: () async {
                          // TADY NAČTEME REZERVACI DO KOŠÍKU!
                          // 1. Musíme najít sudy v našem seznamu products podle ID
                          List<Product> allProducts = await futureProducts;
                          List<CartItem> itemsToLoad = [];

                          for (var item in order['items']) {
                            // Najdeme produkt podle product_id, co nám poslal Django
                            Product? p = allProducts
                                .where((prod) => prod.id == item['product_id'])
                                .firstOrNull;
                            if (p != null) {
                              itemsToLoad.add(
                                CartItem(
                                  product: p,
                                  quantity: item['quantity'],
                                ),
                              );
                            }
                          }

                          // 2. Pošleme to do Cubitu (do paměti)
                          if (context.mounted) {
                            context.read<CartCubit>().loadReservation(
                              order['id'],
                              itemsToLoad,
                            );
                            Navigator.of(context).pop(); // Zavřeme dialog
                          }
                        },
                      ),
                    );
                  },
                );
              },
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('ZAVŘÍT'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Pokladna',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: const PosScreen(),
    );
  }
}

class PosScreen extends StatefulWidget {
  const PosScreen({super.key});

  @override
  State<PosScreen> createState() => _PosScreenState();
}

class _PosScreenState extends State<PosScreen> {
  final ApiService apiService = ApiService();
  late Future<List<Product>> futureProducts;

  @override
  void initState() {
    super.initState();
    futureProducts = apiService.fetchProducts();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('🍺 Pokladna'),
        actions: [
          IconButton(
            icon: const Icon(Icons.cloud_download, color: Colors.white),
            tooltip: 'Čekající rezervace',
            onPressed: () =>
                _showPendingOrdersDialog(context), // Tuto funkci hned vytvoříme
          ),
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: () {
              setState(() {
                futureProducts = apiService.fetchProducts();
              });
            },
          ),
        ],
      ),
      // Zde je to kouzlo: Rozdělíme obrazovku na levý a pravý panel
      body: Row(
        children: [
          // LEVÁ STRANA: Výběr sudů (zabere 2/3 místa)
          Expanded(flex: 2, child: buildProductGrid()),

          // Svislá dělící čára
          const VerticalDivider(width: 1, thickness: 1, color: Colors.grey),

          // PRAVÁ STRANA: Účtenka / Košík (zabere 1/3 místa)
          Expanded(flex: 1, child: buildCartPanel()),
        ],
      ),
    );
  }

  // --- Kód pro levý panel (Vytaháno z původního body) ---
  Widget buildProductGrid() {
    return FutureBuilder<List<Product>>(
      future: futureProducts,
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator());
        } else if (snapshot.hasError) {
          return Center(child: Text('Chyba: ${snapshot.error}'));
        } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
          return const Center(child: Text('Sklad je prázdný.'));
        }

        List<Product> products = snapshot.data!;

        return GridView.builder(
          padding: const EdgeInsets.all(16),
          gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
            maxCrossAxisExtent: 250,
            childAspectRatio: 3 / 2,
            crossAxisSpacing: 16,
            mainAxisSpacing: 1,
          ),
          itemCount: products.length,
          itemBuilder: (context, index) {
            final product = products[index];
            return Card(
              elevation: 4,
              child: InkWell(
                onTap: () {
                  // TÍMTO ZAVOLÁME CUBIT A PŘIDÁME DO KOŠÍKU!
                  context.read<CartCubit>().addProduct(product);
                },
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        product.brand,
                        style: const TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Text(
                        product.volume,
                        style: const TextStyle(color: Colors.grey),
                      ),
                      const SizedBox(height: 1),
                      Text(
                        '${product.price} Kč',
                        style: const TextStyle(
                          fontSize: 16,
                          color: Colors.green,
                        ),
                      ),

                      // NOVÉ: Zobrazení stavu skladu
                      const SizedBox(height: 5),
                      Text(
                        'Skladem: ${product.currentStock} ks',
                        style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.bold,
                          color: Colors
                              .orange
                              .shade700, // Oranžová barva pro odlišení
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            );
          },
        );
      },
    );
  }

  // --- Kód pro pravý panel (Účtenka sledující stav Cubitu) ---
  Widget buildCartPanel() {
    // BlocBuilder zajistí, že se tento panel překreslí POKAŽDÉ, když se změní obsah košíku
    return BlocBuilder<CartCubit, CartState>(
      builder: (context, state) {
        return Column(
          children: [
            // Hlavička účtenky
            Container(
              padding: const EdgeInsets.all(16),
              color: Colors.blue.shade50,
              width: double.infinity,
              child: const Text(
                'Aktuální účtenka',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              ),
            ),

            // Seznam položek
            Expanded(
              child: state.items.isEmpty
                  ? const Center(
                      child: Text(
                        'Účtenka je prázdná',
                        style: TextStyle(color: Colors.grey),
                      ),
                    )
                  : ListView.builder(
                      itemCount: state.items.length,
                      itemBuilder: (context, index) {
                        final item = state.items[index];
                        return ListTile(
                          title: Text(
                            '${item.product.brand} ${item.product.volume}',
                          ),
                          subtitle: Text(
                            '${item.quantity}x ${item.product.price} Kč',
                          ),
                          trailing: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Text(
                                '${item.totalPrice.toStringAsFixed(2)} Kč',
                                style: const TextStyle(
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              IconButton(
                                icon: const Icon(
                                  Icons.remove_circle_outline,
                                  color: Colors.red,
                                ),
                                onPressed: () {
                                  // Odstranění z košíku
                                  context.read<CartCubit>().removeProduct(
                                    item.product,
                                  );
                                },
                              ),
                            ],
                          ),
                        );
                      },
                    ),
            ),

            // Patička s celkovou cenou a tlačítkem Dokončit
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: Colors.white,
                boxShadow: [
                  BoxShadow(
                    color: Colors.black12,
                    blurRadius: 10,
                    offset: const Offset(0, -5),
                  ),
                ],
              ),
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text(
                        'Celkem k úhradě:',
                        style: TextStyle(fontSize: 18),
                      ),
                      Text(
                        '${state.totalAmount.toStringAsFixed(2)} Kč',
                        style: const TextStyle(
                          fontSize: 24,
                          fontWeight: FontWeight.bold,
                          color: Colors.green,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      minimumSize: const Size(double.infinity, 60),
                      backgroundColor: Colors.blue,
                      foregroundColor: Colors.white,
                    ),
                    onPressed: state.items.isEmpty
                        ? null // Pokud je košík prázdný, tlačítko je zašedlé
                        : () {
                            print('TODO: Odeslat do Djanga API!');
                            // Až to odešleme úspěšně, vymažeme košík:
                            // context.read<CartCubit>().clearCart();
                          },
                    child: const Text(
                      'DOKONČIT PRODEJ',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        );
      },
    );
  }
}
