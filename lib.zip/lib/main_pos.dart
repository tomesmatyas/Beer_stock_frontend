import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'models/product.dart';
import 'services/api_service.dart';
import 'cubits/cart_cubit.dart'; // Náš nový Cubit
import 'restock_screen.dart';

void main() {
  runApp(
    // Poskytneme CartCubit celé aplikaci
    BlocProvider(create: (context) => CartCubit(), child: const PosApp()),
  );
}

class PosApp extends StatelessWidget {
  const PosApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Pokladna',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: const PosScreen(),
    );
  }
}

class PosScreen extends StatefulWidget {
  const PosScreen({super.key});

  @override
  State<PosScreen> createState() => _PosScreenState();
}

class _PosScreenState extends State<PosScreen> {
  final ApiService apiService = ApiService();
  late Future<List<Product>> futureProducts;

  @override
  void initState() {
    super.initState();
    futureProducts = apiService.fetchProducts();
  }

  // 1. Funkce pro simulaci tisku (vyskočí okno s náhledem účtenky)
  void _printOrder(dynamic order) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('TISK ÚČTENKY'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Číslo účtenky: #${order['id']}'),
            Text('Datum: ${order['created_at']}'),
            const Divider(),
            ...(order['items'] as List).map(
              (i) => Text('${i['quantity']}x ${i['brand']} - ${i['price']} Kč'),
            ),
            const Divider(),
            Text(
              'CELKEM: ${order['total_amount']} Kč',
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('OK'),
          ),
        ],
      ),
    );
  }

  // 2. Dialog se seznamem všech účtenek
  void _showOrdersHistoryDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Historie prodejů'),
        content: SizedBox(
          width: double.maxFinite,
          height: 500,
          child: FutureBuilder<List<dynamic>>(
            future: apiService.fetchOrderHistory(),
            builder: (context, snapshot) {
              if (!snapshot.hasData)
                return const Center(child: CircularProgressIndicator());
              final orders = snapshot.data!;
              return ListView.builder(
                itemCount: orders.length,
                itemBuilder: (context, index) {
                  final order = orders[index];
                  return ListTile(
                    title: Text(
                      'Účtenka č. ${order['receipt_number']} - ${order['total_amount']} Kč',
                    ),
                    subtitle: Text(order['created_at']),
                    trailing: IconButton(
                      icon: const Icon(Icons.print),
                      onPressed: () => _printOrder(order),
                    ),
                  );
                },
              );
            },
          ),
        ),
      ),
    );
  }

  // OPRAVA 1: Funkce přesunuta SEM, kde zná apiService a futureProducts!
  void _showPendingOrdersDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (ctx) {
        return AlertDialog(
          title: const Text('Čekající rezervace'),
          content: SizedBox(
            width: double.maxFinite,
            height: 400,
            child: FutureBuilder<List<dynamic>>(
              future: apiService.fetchPendingOrders(),
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(child: CircularProgressIndicator());
                } else if (snapshot.hasError) {
                  return Text('Chyba: ${snapshot.error}');
                } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
                  return const Center(child: Text('Žádné čekající rezervace.'));
                }

                final orders = snapshot.data!;
                return ListView.builder(
                  itemCount: orders.length,
                  itemBuilder: (context, index) {
                    final order = orders[index];
                    return ListTile(
                      leading: const Icon(Icons.person),
                      title: Text(
                        '${order['customer']} - ${order['total_amount']} Kč',
                      ),
                      subtitle: Text(
                        'Vyzvednutí: ${order['pickup_date'] ?? 'Nezadáno'}',
                      ),
                      trailing: IconButton(
                        icon: const Icon(
                          Icons.check_circle,
                          color: Colors.green,
                        ),
                        onPressed: () async {
                          // Načteme rezervaci do košíku
                          List<Product> allProducts = await futureProducts;
                          List<CartItem> itemsToLoad = [];

                          for (var item in order['items']) {
                            // Změň porovnání ID na bezpečnější verzi:
                            Product? p = allProducts
                                .where(
                                  (prod) =>
                                      prod.id.toString() ==
                                      item['product_id'].toString(),
                                )
                                .firstOrNull;
                            if (p != null) {
                              itemsToLoad.add(
                                CartItem(
                                  product: p,
                                  quantity: item['quantity'],
                                ),
                              );
                            }
                          }

                          if (context.mounted) {
                            context.read<CartCubit>().loadReservation(
                              order['id'],
                              itemsToLoad,
                            );
                            Navigator.of(context).pop(); // Zavřeme dialog
                          }
                        },
                      ),
                    );
                  },
                );
              },
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('ZAVŘÍT'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('🍺 Pokladna'),
        actions: [
          IconButton(
            icon: const Icon(Icons.local_shipping, color: Colors.white),
            tooltip: 'Příjem zboží (Naskladnění)',
            onPressed: () async {
              // 1. Otevřeme novou stránku a čekáme na výsledek (didRestock)
              final didRestock = await Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const RestockScreen()),
              );

              // 2. Pokud nám nová stránka vrátila "true" (Něco se naskladnilo)
              if (didRestock == true) {
                // Znovu načteme levý panel se sudy
                setState(() {
                  futureProducts = apiService.fetchProducts();
                });
              }
            },
          ),
          IconButton(
            icon: const Icon(Icons.history, color: Colors.white),
            tooltip: 'Historie účtenek',
            onPressed: () => _showOrdersHistoryDialog(context),
          ),
          IconButton(
            icon: const Icon(Icons.cloud_download, color: Colors.white),
            tooltip: 'Čekající rezervace',
            onPressed: () => _showPendingOrdersDialog(context),
          ),
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: () {
              setState(() {
                futureProducts = apiService.fetchProducts();
              });
            },
          ),
        ],
      ),
      body: Row(
        children: [
          Expanded(flex: 2, child: buildProductGrid()),
          const VerticalDivider(width: 1, thickness: 1, color: Colors.grey),
          Expanded(flex: 1, child: buildCartPanel()),
        ],
      ),
    );
  }

  Widget buildProductGrid() {
    return FutureBuilder<List<Product>>(
      future: futureProducts,
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator());
        } else if (snapshot.hasError) {
          return Center(child: Text('Chyba: ${snapshot.error}'));
        } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
          return const Center(child: Text('Sklad je prázdný.'));
        }

        List<Product> products = snapshot.data!;

        return GridView.builder(
          padding: const EdgeInsets.all(16),
          gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
            maxCrossAxisExtent: 250,
            childAspectRatio: 3 / 2,
            crossAxisSpacing: 16,
            mainAxisSpacing: 1,
          ),
          itemCount: products.length,
          itemBuilder: (context, index) {
            final product = products[index];
            return Card(
              elevation: 4,
              child: InkWell(
                onTap: () {
                  context.read<CartCubit>().addProduct(product);
                },
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        product.brand,
                        style: const TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Text(
                        product.volume,
                        style: const TextStyle(color: Colors.grey),
                      ),
                      const SizedBox(height: 1),
                      Text(
                        '${product.price} Kč',
                        style: const TextStyle(
                          fontSize: 16,
                          color: Colors.green,
                        ),
                      ),
                      const SizedBox(height: 5),
                      Text(
                        'Skladem: ${product.currentStock} ks',
                        style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.bold,
                          color: Colors.orange.shade700,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            );
          },
        );
      },
    );
  }

  Widget buildCartPanel() {
    return BlocBuilder<CartCubit, CartState>(
      builder: (context, state) {
        return Column(
          children: [
            Container(
              padding: const EdgeInsets.all(16),
              color: Colors.blue.shade50,
              width: double.infinity,
              child: const Text(
                'Aktuální účtenka',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              ),
            ),
            Expanded(
              child: state.items.isEmpty
                  ? const Center(
                      child: Text(
                        'Účtenka je prázdná',
                        style: TextStyle(color: Colors.grey),
                      ),
                    )
                  : ListView.builder(
                      itemCount: state.items.length,
                      itemBuilder: (context, index) {
                        final item = state.items[index];
                        return ListTile(
                          title: Text(
                            '${item.product.brand} ${item.product.volume}',
                          ),
                          subtitle: Text(
                            '${item.quantity}x ${item.product.price} Kč',
                          ),
                          trailing: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Text(
                                '${item.totalPrice.toStringAsFixed(2)} Kč',
                                style: const TextStyle(
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              IconButton(
                                icon: const Icon(
                                  Icons.remove_circle_outline,
                                  color: Colors.red,
                                ),
                                onPressed: () {
                                  context.read<CartCubit>().removeProduct(
                                    item.product,
                                  );
                                },
                              ),
                            ],
                          ),
                        );
                      },
                    ),
            ),
            // Patička s celkovou cenou a tlačítky
            Container(
              padding: const EdgeInsets.all(20),
              decoration: const BoxDecoration(
                color: Colors.white,
                boxShadow: [
                  BoxShadow(
                    color: Colors.black12,
                    blurRadius: 10,
                    offset: Offset(0, -5),
                  ),
                ],
              ),
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text(
                        'Celkem k úhradě:',
                        style: TextStyle(fontSize: 18),
                      ),
                      Text(
                        '${state.totalAmount.toStringAsFixed(2)} Kč',
                        style: const TextStyle(
                          fontSize: 24,
                          fontWeight: FontWeight.bold,
                          color: Colors.green,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),

                  // NOVÉ: Dvě tlačítka vedle sebe (Odložit a Dokončit)
                  Row(
                    children: [
                      // 1. TLAČÍTKO: Vymazat / Odložit (Červené)
                      Expanded(
                        flex: 1, // Zabere 1 díl šířky
                        child: OutlinedButton(
                          style: OutlinedButton.styleFrom(
                            padding: const EdgeInsets.symmetric(vertical: 18),
                            foregroundColor: Colors.red,
                            side: const BorderSide(color: Colors.red),
                          ),
                          onPressed: state.items.isEmpty
                              ? null
                              : () {
                                  // Jen vyčistíme paměť telefonu (Cubit), na server nic neposíláme!
                                  context.read<CartCubit>().clearCart();
                                },
                          child: Text(
                            // Text se chytře mění podle toho, co zrovna děláš
                            state.loadedOrderId != null
                                ? 'ODLOŽIT\nREZERVACI'
                                : 'ZRUŠIT\nPRODEJ',
                            textAlign: TextAlign.center,
                            style: const TextStyle(fontWeight: FontWeight.bold),
                          ),
                        ),
                      ),

                      const SizedBox(width: 12), // Mezera mezi tlačítky
                      // 2. TLAČÍTKO: Dokončit prodej (Modré)
                      Expanded(
                        flex: 2, // Zabere 2 díly šířky (je větší)
                        child: ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            padding: const EdgeInsets.symmetric(vertical: 24),
                            backgroundColor: Colors.blue,
                            foregroundColor: Colors.white,
                          ),
                          onPressed: state.items.isEmpty
                              ? null
                              : () async {
                                  try {
                                    // TADY JE TEN ROZCESTNÍK!
                                    if (state.loadedOrderId != null) {
                                      // 1. SCÉNÁŘ: Byla načtena REZERVACE
                                      await apiService.fulfillOrder(
                                        state.loadedOrderId!,
                                        state.items,
                                        state.totalAmount,
                                      );
                                      if (context.mounted) {
                                        ScaffoldMessenger.of(
                                          context,
                                        ).showSnackBar(
                                          const SnackBar(
                                            content: Text(
                                              'Rezervace úspěšně vyřízena!',
                                            ),
                                          ),
                                        );
                                      }
                                    } else {
                                      // 2. SCÉNÁŘ: Je to BĚŽNÝ PRODEJ Z ULICE
                                      await apiService.createOrder(
                                        state.items,
                                        state.totalAmount,
                                      );
                                      if (context.mounted) {
                                        ScaffoldMessenger.of(
                                          context,
                                        ).showSnackBar(
                                          const SnackBar(
                                            content: Text(
                                              'Prodej z ulice úspěšně dokončen (sklad odečten)!',
                                            ),
                                          ),
                                        );
                                      }
                                    }

                                    // Vše proběhlo OK, vyčistíme košík
                                    if (context.mounted) {
                                      context.read<CartCubit>().clearCart();
                                      // Volitelně: Můžeš znovu načíst produkty, aby se hned zaktualizoval stav skladu v levém panelu
                                      setState(() {
                                        futureProducts = apiService
                                            .fetchProducts();
                                      });
                                    }
                                  } catch (e) {
                                    if (context.mounted) {
                                      ScaffoldMessenger.of(
                                        context,
                                      ).showSnackBar(
                                        SnackBar(content: Text('Chyba: $e')),
                                      );
                                    }
                                  }
                                },
                          child: const Text(
                            'DOKONČIT PRODEJ',
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        );
      },
    );
  }
}
