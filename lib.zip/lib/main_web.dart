import 'package:flutter/material.dart';
import 'package:beer_stock/services/api_service.dart';

void main() {
  runApp(const ZazemiWebApp());
}

class ZazemiWebApp extends StatelessWidget {
  const ZazemiWebApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Pivní Sklad',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        // Zlatá/Jantarová je pro pivo ideální barva!
        primarySwatch: Colors.amber,
        scaffoldBackgroundColor: Colors.grey[50],
      ),
      // Definice "adres" na našem webu
      initialRoute: '/',
      routes: {
        '/': (context) => const WebLayout(child: HomePage()),
        '/kontakt': (context) => const WebLayout(child: ContactPage()),
        '/rezervace': (context) => const WebLayout(child: ReservationPage()),
      },
    );
  }
}

// --- HLAVNÍ OBAL STRÁNKY (Tohle bude vidět všude) ---
class WebLayout extends StatelessWidget {
  final Widget child;
  const WebLayout({super.key, required this.child});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.black87,
        toolbarHeight: 80, // Trochu vyšší lišta ať to vypadá jako web, ne appka
        title: InkWell(
          onTap: () => Navigator.pushReplacementNamed(context, '/'),
          child: const Row(
            children: [
              Text('🍺 ', style: TextStyle(fontSize: 30)),
              Text(
                'PIVNÍ SKLAD',
                style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 2,
                ),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pushReplacementNamed(context, '/'),
            child: const Text(
              'O NÁS',
              style: TextStyle(color: Colors.white, fontSize: 16),
            ),
          ),
          const SizedBox(width: 20),
          TextButton(
            onPressed: () =>
                Navigator.pushReplacementNamed(context, '/kontakt'),
            child: const Text(
              'KONTAKT',
              style: TextStyle(color: Colors.white, fontSize: 16),
            ),
          ),
          const SizedBox(width: 30),

          // TOHLE TLAČÍTKO CHCEME MÍT VŠUDE!
          Padding(
            padding: const EdgeInsets.symmetric(
              vertical: 16.0,
              horizontal: 20.0,
            ),
            child: ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.amber,
                foregroundColor: Colors.black,
                elevation: 5,
                padding: const EdgeInsets.symmetric(horizontal: 30),
              ),
              onPressed: () {
                // Tady nebudeme dělat Replacement, ať se může uživatel vrátit zpět
                Navigator.pushNamed(context, '/rezervace');
              },
              child: const Text(
                'REZERVOVAT SUDY',
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
              ),
            ),
          ),
        ],
      ),
      body: child, // Zde se vykreslí konkrétní stránka
    );
  }
}

// --- 1. ÚVODNÍ STRÁNKA ---
class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(Icons.sports_bar, size: 100, color: Colors.amber),
          const SizedBox(height: 20),
          const Text(
            'Vítejte v našem skladu!',
            style: TextStyle(fontSize: 40, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 20),
          const SizedBox(
            width: 600,
            child: Text(
              'Jsme tu pro všechny hasiče, spolky i víkendové grilovače. '
              'Udělejte si online rezervaci a sudy vám připravíme rovnou k vyzvednutí.',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 18, height: 1.5),
            ),
          ),
          const SizedBox(height: 40),
          OutlinedButton(
            onPressed: () =>
                Navigator.pushReplacementNamed(context, '/kontakt'),
            child: const Text('Kde nás najdete?'),
          ),
        ],
      ),
    );
  }
}

// --- 2. STRÁNKA KONTAKT ---
class ContactPage extends StatelessWidget {
  const ContactPage({super.key});

  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            'Kontakt a Otevírací doba',
            style: TextStyle(fontSize: 40, fontWeight: FontWeight.bold),
          ),
          SizedBox(height: 20),
          Text('📍 Adresa: Lično 123', style: TextStyle(fontSize: 20)),
          Text('📞 Telefon: +420 123 456 789', style: TextStyle(fontSize: 20)),
          SizedBox(height: 40),
          Text(
            'Otevřeno pátky a soboty dle domluvy.',
            style: TextStyle(fontSize: 16, fontStyle: FontStyle.italic),
          ),
        ],
      ),
    );
  }
}

// --- 3. REZERVAČNÍ STRÁNKA (Zatím prázdná, sem napojíme Django) ---
class ReservationPage extends StatefulWidget {
  const ReservationPage({super.key});

  @override
  State<ReservationPage> createState() => _ReservationPageState();
}

class _ReservationPageState extends State<ReservationPage> {
  final ApiService apiService = ApiService();
  List<dynamic> availableProducts = [];
  bool isLoading = true;

  // Jednoduchý košík pro web (nepotřebujeme složitý Cubit)
  // Mapa: Product -> Počet kusů
  Map<dynamic, int> cart = {};

  // Textové kontrolery pro formulář
  final TextEditingController nameController = TextEditingController();
  final TextEditingController phoneController = TextEditingController();
  final TextEditingController assocController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _loadProducts();
  }

  Future<void> _loadProducts() async {
    try {
      // Využije tvou existující funkci fetchProducts
      final products = await apiService.fetchProducts();
      setState(() {
        availableProducts = products;
        isLoading = false;
      });
    } catch (e) {
      setState(() => isLoading = false);
      print(e);
    }
  }

  double get cartTotal {
    double total = 0;
    cart.forEach((product, qty) {
      total += double.parse(product.price.toString()) * qty;
    });
    return total;
  }

  void _submitReservation() async {
    if (cart.isEmpty || nameController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Musíte vybrat sudy a vyplnit alespoň Jméno a Příjmení!',
          ),
        ),
      );
      return;
    }

    // Převod košíku pro Django
    List<Map<String, dynamic>> itemsForDjango = [];
    cart.forEach((product, qty) {
      itemsForDjango.add({"product_id": product.id, "quantity": qty});
    });

    try {
      await apiService.submitWebReservation(
        items: itemsForDjango,
        totalAmount: cartTotal,
        customerName: nameController.text,
        customerPhone: phoneController.text,
        associationName: assocController.text,
      );

      // Úspěch! Vyčistíme web a ukážeme zprávu
      setState(() {
        cart.clear();
        nameController.clear();
        phoneController.clear();
        assocController.clear();
      });

      if (context.mounted) {
        showDialog(
          context: context,
          builder: (ctx) => AlertDialog(
            title: const Text('🎉 Rezervace odeslána!'),
            content: const Text(
              'Tvoje sudy jsou na tebe připravené na skladě.',
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(ctx),
                child: const Text('SKVĚLÉ'),
              ),
            ],
          ),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text(e.toString())));
    }
  }

  @override
  Widget build(BuildContext context) {
    if (isLoading) return const Center(child: CircularProgressIndicator());

    return Padding(
      padding: const EdgeInsets.all(32.0),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // LEVÁ STRANA: Nabídka sudů
          Expanded(
            flex: 2,
            child: GridView.builder(
              gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
                maxCrossAxisExtent: 300,
                crossAxisSpacing: 20,
                mainAxisSpacing: 20,
                childAspectRatio: 0.9,
              ),
              itemCount: availableProducts.length,
              itemBuilder: (context, index) {
                final prod = availableProducts[index];
                return Card(
                  elevation: 5,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(15),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Icon(
                          Icons.sports_bar,
                          size: 60,
                          color: Colors.amber,
                        ),
                        const SizedBox(height: 10),
                        Text(
                          prod.brand,
                          style: const TextStyle(
                            fontSize: 22,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        Text(
                          '${prod.volume}',
                          style: const TextStyle(
                            color: Colors.grey,
                            fontSize: 16,
                          ),
                        ),
                        const SizedBox(height: 10),
                        Text(
                          '${prod.price} Kč',
                          style: const TextStyle(
                            fontSize: 20,
                            color: Colors.green,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const Spacer(),
                        ElevatedButton.icon(
                          icon: const Icon(Icons.add_shopping_cart),
                          label: const Text('Přidat'),
                          onPressed: () {
                            setState(() {
                              cart[prod] = (cart[prod] ?? 0) + 1;
                            });
                          },
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),

          const SizedBox(width: 32),

          // PRAVÁ STRANA: Košík a Kontaktní formulář
          Expanded(
            flex: 1,
            child: Card(
              elevation: 8,
              color: Colors.white,
              child: Padding(
                padding: const EdgeInsets.all(24.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    const Text(
                      'Váš košík',
                      style: TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const Divider(thickness: 2),

                    // Výpis položek
                    if (cart.isEmpty)
                      const Padding(
                        padding: EdgeInsets.symmetric(vertical: 20),
                        child: Text(
                          'Zatím jste nevybrali žádné sudy.',
                          style: TextStyle(color: Colors.grey),
                        ),
                      )
                    else
                      ...cart.entries.map(
                        (entry) => ListTile(
                          contentPadding: EdgeInsets.zero,
                          title: Text('${entry.key.brand} ${entry.key.volume}'),
                          subtitle: Text(
                            '${entry.value}x ${entry.key.price} Kč',
                          ),
                          trailing: IconButton(
                            icon: const Icon(Icons.delete, color: Colors.red),
                            onPressed: () =>
                                setState(() => cart.remove(entry.key)),
                          ),
                        ),
                      ),

                    const Divider(thickness: 2),
                    Text(
                      'CELKEM: ${cartTotal.toStringAsFixed(2)} Kč',
                      style: const TextStyle(
                        fontSize: 22,
                        fontWeight: FontWeight.bold,
                        color: Colors.green,
                      ),
                      textAlign: TextAlign.right,
                    ),

                    const SizedBox(height: 30),
                    const Text(
                      'Kontaktní údaje',
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 10),
                    TextField(
                      controller: nameController,
                      decoration: const InputDecoration(
                        labelText: 'Jméno a Příjmení *',
                        border: OutlineInputBorder(),
                      ),
                    ),
                    const SizedBox(height: 15),
                    TextField(
                      controller: phoneController,
                      decoration: const InputDecoration(
                        labelText: 'Telefon',
                        border: OutlineInputBorder(),
                      ),
                    ),
                    const SizedBox(height: 15),
                    TextField(
                      controller: assocController,
                      decoration: const InputDecoration(
                        labelText: 'Spolek / SDH (volitelné)',
                        border: OutlineInputBorder(),
                      ),
                    ),

                    const SizedBox(height: 30),
                    ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.amber,
                        foregroundColor: Colors.black,
                        padding: const EdgeInsets.symmetric(vertical: 20),
                      ),
                      onPressed: _submitReservation,
                      child: const Text(
                        'ODESLAT REZERVACI',
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
