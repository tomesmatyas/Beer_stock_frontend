class Product {
  final int id;
  final String brand;
  final String volume;
  final String price; // Django DecimalField se v JSONu posílá jako String
  final int currentStock;

  Product({
    required this.id,
    required this.brand,
    required this.volume,
    required this.price,
    required this.currentStock,
  });

  factory Product.fromJson(Map<String, dynamic> json) {
    return Product(
      id: json['id'],
      brand: json['brand'],
      volume: json['volume'],
      price: json['price'],
      currentStock: json['current_stock'],
    );
  }
}
