import 'package:flutter_bloc/flutter_bloc.dart';
import '../models/product.dart';

// 1. Pomocná třída pro položku v košíku (Sud + Počet kusů)
class CartItem {
  final Product product;
  int quantity;

  CartItem({required this.product, this.quantity = 1});

  // Rychlý výpočet ceny za tuto položku
  double get totalPrice => double.parse(product.price) * quantity;
}

// 2. Stav košíku (To, co vidí obrazovka)
class CartState {
  final List<CartItem> items;
  final double totalAmount;
  final int? loadedOrderId; // <--- NOVÉ: Pokud není null, řešíme rezervaci

  CartState({
    required this.items,
    required this.totalAmount,
    this.loadedOrderId,
  });
}

// 3. Samotný Cubit (Mozek, který mění stav)
class CartCubit extends Cubit<CartState> {
  CartCubit()
    : super(CartState(items: [], totalAmount: 0.0, loadedOrderId: null));

  // --- NOVÉ METODY PRO REZERVACE ---

  // Načte celou online rezervaci do pokladny
  void loadReservation(int orderId, List<CartItem> reservationItems) {
    emit(
      CartState(
        items: reservationItems,
        totalAmount: reservationItems.fold(
          0,
          (sum, item) => sum + item.totalPrice,
        ),
        loadedOrderId: orderId, // Pamatujeme si, čí to je objednávka!
      ),
    );
  }

  // Po zaplacení (nebo ručním smazání) vyčistí košík a zapomene rezervaci
  void clearCart() {
    emit(CartState(items: [], totalAmount: 0.0, loadedOrderId: null));
  }

  // --- STANDARDNÍ METODY POKLADNY ---

  // Přidání sudu do košíku (s kontrolou skladu)
  void addProduct(Product product) {
    final List<CartItem> currentItems = List.from(state.items);
    final existingIndex = currentItems.indexWhere(
      (item) => item.product.id == product.id,
    );

    if (existingIndex >= 0) {
      // Sud už v košíku je. Přidáme další kus POUZE, pokud nepřekročíme sklad!
      if (currentItems[existingIndex].quantity < product.currentStock) {
        currentItems[existingIndex].quantity += 1;
      } else {
        print(
          'Nelze přidat více! Skladem je pouze ${product.currentStock} ks.',
        );
      }
    } else {
      // Sud v košíku není. Můžeme ho přidat
      if (product.currentStock > 0) {
        currentItems.add(CartItem(product: product));
      }
    }

    _emitUpdatedState(currentItems);
  }

  // Odstranění sudu (nebo snížení počtu)
  void removeProduct(Product product) {
    final List<CartItem> currentItems = List.from(state.items);
    final existingIndex = currentItems.indexWhere(
      (item) => item.product.id == product.id,
    );

    if (existingIndex >= 0) {
      if (currentItems[existingIndex].quantity > 1) {
        currentItems[existingIndex].quantity -= 1;
      } else {
        currentItems.removeAt(existingIndex);
      }
    }

    _emitUpdatedState(currentItems);
  }

  // Pomocná metoda pro přepočet celkové ceny a vydání nového stavu
  void _emitUpdatedState(List<CartItem> items) {
    double total = 0;
    for (var item in items) {
      total += item.totalPrice;
    }

    // OPRAVA: Musíme stavu předat i loadedOrderId, aby to nezapomněl!
    emit(
      CartState(
        items: items,
        totalAmount: total,
        loadedOrderId: state.loadedOrderId, // TADY JE TO KOUZLO
      ),
    );
  }
}
