import 'dart:convert';
import 'package:http/http.dart' as http;
import '../../models/product.dart';
import '../cubits/cart_cubit.dart';

class ApiService {
  // Změňte IP adresu podle toho, kde to testujete (127.0.0.1 pro Web, 10.0.2.2 pro Android emulátor)
  static const String apiUrl = 'http://127.0.0.1:8000/api/products/';
  static const String orderUrl = 'http://127.0.0.1:8000/api/orders/create/';
  static const String refundUrl = 'http://127.0.0.1:8000/api/orders/refund/';

  // Změň IP adresu, pokud testuješ jinde
  static const String pendingOrdersUrl =
      'http://127.0.0.1:8000/api/orders/pending/';
  static const String fulfillOrderUrl =
      'http://127.0.0.1:8000/api/orders/'; // id se přidá dynamicky
  static const String historyUrl = 'http://127.0.0.1:8000/api/orders/history/';
  static const String createOrderUrl =
      'http://127.0.0.1:8000/api/orders/create/';
  static const String fulfillOrderBaseUrl = 'http://127.0.0.1:8000/api/orders/';
  static const String createReservationUrl =
      'http://127.0.0.1:8000/api/orders/reserve/';
  static const String allProductsUrl =
      'http://127.0.0.1:8000/api/products/all/';
  static const String restockUrl =
      'http://127.0.0.1:8000/api/products/restock/';

  // Stáhne úplně všechny produkty
  Future<List<dynamic>> fetchAllProducts() async {
    final response = await http.get(Uri.parse(allProductsUrl));
    if (response.statusCode == 200) {
      final List<dynamic> data = json.decode(utf8.decode(response.bodyBytes));
      return data.map((json) => Product.fromJson(json)).toList();
    } else {
      throw Exception('Chyba při načítání všech produktů');
    }
  }

  // Odešle data k naskladnění
  Future<void> restockProducts(List<Map<String, dynamic>> items) async {
    final response = await http.post(
      Uri.parse(restockUrl),
      headers: {"Content-Type": "application/json"},
      body: json.encode({"items": items}),
    );

    if (response.statusCode != 200) {
      throw Exception('Chyba při naskladnění: ${response.body}');
    }
  }

  // 1. Stáhne čekající rezervace
  Future<List<dynamic>> fetchPendingOrders() async {
    final response = await http.get(Uri.parse(pendingOrdersUrl));
    if (response.statusCode == 200) {
      return json.decode(utf8.decode(response.bodyBytes));
    } else {
      throw Exception('Chyba při stahování rezervací');
    }
  }

  Future<List<dynamic>> fetchOrderHistory() async {
    final response = await http.get(Uri.parse(historyUrl));
    if (response.statusCode == 200) {
      return json.decode(utf8.decode(response.bodyBytes));
    }
    throw Exception('Chyba historie');
  }

  // 2. Vyřídí (zaplatí) konkrétní rezervaci
  Future<void> fulfillOrder(
    int orderId,
    List<CartItem> items,
    double totalAmount,
  ) async {
    final List<Map<String, dynamic>> orderItems = items
        .map(
          (item) => {"product_id": item.product.id, "quantity": item.quantity},
        )
        .toList();

    final response = await http.post(
      Uri.parse('$fulfillOrderBaseUrl$orderId/fulfill/'),
      headers: {"Content-Type": "application/json"},
      body: json.encode({"items": orderItems, "total_amount": totalAmount}),
    );

    if (response.statusCode != 200) {
      throw Exception('Chyba při vyřizování rezervace: ${response.body}');
    }
  }

  // 3. Zruší propadlou rezervaci (vrátí sudy na sklad)
  Future<void> cancelOrder(int orderId) async {
    final response = await http.post(
      Uri.parse('$fulfillOrderUrl$orderId/cancel/'),
    );
    if (response.statusCode != 200) {
      throw Exception('Chyba při rušení rezervace');
    }
  }

  // NOVÁ FUNKCE PRO BĚŽNÝ PRODEJ
  Future<void> createOrder(
    List<CartItem> items,
    double totalAmount,
    int kegsRented, // <--- NOVÉ
    int kegsReturned,
  ) async {
    // Převedeme naše sudy z košíku do formátu pro Django
    final List<Map<String, dynamic>> orderItems = items
        .map(
          (item) => {"product_id": item.product.id, "quantity": item.quantity},
        )
        .toList();

    final response = await http.post(
      Uri.parse(createOrderUrl),
      headers: {"Content-Type": "application/json"},
      body: json.encode({
        "items": orderItems,
        "total_amount": totalAmount,
        "kegs_rented": kegsRented, // <--- ODESLÁNÍ DO DJANGA
        "kegs_returned": kegsReturned,
      }),
    );

    if (response.statusCode != 201) {
      throw Exception('Chyba při odesílání prodeje: ${response.body}');
    }
  }

  Future<List<Product>> fetchProducts() async {
    try {
      final response = await http.get(Uri.parse(apiUrl));

      if (response.statusCode == 200) {
        // Dekódování JSONu z UTF-8 (aby fungovala česká diakritika)
        List<dynamic> body = json.decode(utf8.decode(response.bodyBytes));
        return body.map((dynamic item) => Product.fromJson(item)).toList();
      } else {
        throw Exception('Chyba při načítání dat z API');
      }
    } catch (e) {
      throw Exception('Nelze se připojit k serveru: $e');
    }
  }

  Future<void> refundOrder(
    List<Map<String, dynamic>> items,
    double totalAmount,
  ) async {
    final response = await http.post(
      Uri.parse(refundUrl),
      headers: {"Content-Type": "application/json"},
      body: json.encode({"items": items, "total_amount": totalAmount}),
    );

    if (response.statusCode != 201) {
      throw Exception('Chyba při refundaci: ${response.body}');
    }
  }

  Future<void> submitWebReservation({
    required List<Map<String, dynamic>> items,
    required double totalAmount,
    required String customerName,
    required String customerPhone,
    required String associationName,
  }) async {
    final response = await http.post(
      Uri.parse(createReservationUrl),
      headers: {"Content-Type": "application/json"},
      body: json.encode({
        "items": items,
        "total_amount": totalAmount,
        "customer_name": customerName,
        "customer_phone": customerPhone,
        "association_name": associationName,
      }),
    );

    if (response.statusCode != 201) {
      throw Exception('Chyba při odesílání rezervace: ${response.body}');
    }
  }
}
