import 'package:flutter/material.dart';
import '/services/api_service.dart';
import 'models/product.dart';

class RestockScreen extends StatefulWidget {
  const RestockScreen({super.key});

  @override
  State<RestockScreen> createState() => _RestockScreenState();
}

class _RestockScreenState extends State<RestockScreen> {
  final ApiService apiService = ApiService();
  List<dynamic> allProducts = [];
  bool isLoading = true;
  Map<int, int> restockQuantities = {};

  @override
  void initState() {
    super.initState();
    _loadAllProducts();
  }

  Future<void> _loadAllProducts() async {
    try {
      final products = await apiService.fetchAllProducts();
      setState(() {
        allProducts = products;
        for (var prod in products) {
          restockQuantities[prod.id] = 0;
        }
        isLoading = false;
      });
    } catch (e) {
      setState(() => isLoading = false);
      if (mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text('Chyba: $e')));
      }
    }
  }

  void _updateQty(int productId, int delta) {
    setState(() {
      int current = restockQuantities[productId] ?? 0;
      int next = current + delta;
      if (next < 0) next = 0;
      restockQuantities[productId] = next;
    });
  }

  int get totalRestockItems {
    int total = 0;
    restockQuantities.values.forEach((qty) => total += qty);
    return total;
  }

  Future<void> _submitRestock() async {
    if (totalRestockItems == 0) return;
    List<Map<String, dynamic>> itemsForDjango = [];
    restockQuantities.forEach((id, qty) {
      if (qty > 0) {
        itemsForDjango.add({"product_id": id, "quantity": qty});
      }
    });

    try {
      await apiService.restockProducts(itemsForDjango);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Hromadný příjem proběhl úspěšně!')),
        );
        Navigator.pop(context, true);
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text('Chyba: $e')));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[100],
      appBar: AppBar(
        title: const Text('Rychlý příjem zboží'),
        backgroundColor: Colors.black87,
        foregroundColor: Colors.white,
      ),
      body: isLoading
          ? const Center(child: CircularProgressIndicator())
          : Padding(
              padding: const EdgeInsets.all(16.0), // Menší padding okolo mřížky
              child: GridView.builder(
                gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
                  maxCrossAxisExtent:
                      220, // ZMENŠENO: Původně 320, teď se jich vejde víc vedle sebe
                  crossAxisSpacing: 4,
                  mainAxisSpacing: 4,
                  childAspectRatio:
                      0.8, // Upravený poměr, aby se vše vešlo na výšku
                ),
                itemCount: allProducts.length,
                itemBuilder: (context, index) {
                  final prod = allProducts[index];
                  final qtyToAdd = restockQuantities[prod.id] ?? 0;

                  return Card(
                    elevation: 3,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(
                        10.0,
                      ), // Menší padding uvnitř karty
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const Icon(
                            Icons.sports_bar,
                            size: 35,
                            color: Colors.amber,
                          ), // Menší ikona
                          const SizedBox(height: 5),
                          Text(
                            prod.brand,
                            textAlign: TextAlign.center,
                            maxLines: 1, // Zamezíme přetečení textu
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          Text(
                            prod.volume,
                            style: const TextStyle(
                              color: Colors.grey,
                              fontSize: 12,
                            ),
                          ),
                          const Divider(height: 15),

                          // PLÁNOVANÝ PŘÍJEM (Hlavní číslo)
                          Text(
                            '+ $qtyToAdd',
                            style: TextStyle(
                              fontSize: 22,
                              fontWeight: FontWeight.bold,
                              color: qtyToAdd > 0
                                  ? Colors.green
                                  : Colors.grey[400],
                            ),
                          ),
                          const Spacer(),

                          // --- TLAČÍTKA PO 1 KUSE ---
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              _buildCircleButton(
                                icon: Icons.remove,
                                color: Colors.red,
                                onPressed: () => _updateQty(prod.id, -1),
                              ),
                              const Padding(
                                padding: EdgeInsets.symmetric(horizontal: 8),
                                child: Text(
                                  '1ks',
                                  style: TextStyle(
                                    fontSize: 10,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                              _buildCircleButton(
                                icon: Icons.add,
                                color: Colors.green,
                                onPressed: () => _updateQty(prod.id, 1),
                              ),
                            ],
                          ),

                          const SizedBox(height: 8),

                          // --- TLAČÍTKA PO 6 KUSECH (PALETA) ---
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              _buildSquareButton(
                                label: '-6',
                                color: Colors.red[700]!,
                                onPressed: () => _updateQty(prod.id, -6),
                              ),
                              const Padding(
                                padding: EdgeInsets.symmetric(horizontal: 6),
                                child: Text(
                                  'PAL',
                                  style: TextStyle(
                                    fontSize: 10,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                              _buildSquareButton(
                                label: '+6',
                                color: Colors.green[700]!,
                                onPressed: () => _updateQty(prod.id, 6),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
      bottomNavigationBar: _buildBottomBar(),
    );
  }

  Widget _buildCircleButton({
    required IconData icon,
    required Color color,
    required VoidCallback onPressed,
  }) {
    return InkWell(
      onTap: onPressed,
      child: Container(
        padding: const EdgeInsets.all(4),
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          border: Border.all(color: color, width: 1.5),
        ),
        child: Icon(icon, color: color, size: 18),
      ),
    );
  }

  Widget _buildSquareButton({
    required String label,
    required Color color,
    required VoidCallback onPressed,
  }) {
    return SizedBox(
      width: 42,
      height: 30,
      child: OutlinedButton(
        style: OutlinedButton.styleFrom(
          padding: EdgeInsets.zero,
          side: BorderSide(color: color, width: 1.5),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(6)),
        ),
        onPressed: onPressed,
        child: Text(
          label,
          style: TextStyle(
            color: color,
            fontWeight: FontWeight.bold,
            fontSize: 13,
          ),
        ),
      ),
    );
  }

  Widget _buildBottomBar() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: const BoxDecoration(
        color: Colors.white,
        boxShadow: [
          BoxShadow(
            color: Colors.black12,
            blurRadius: 10,
            offset: Offset(0, -5),
          ),
        ],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            '$totalRestockItems sudů celkem',
            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          ElevatedButton.icon(
            style: ElevatedButton.styleFrom(
              backgroundColor: totalRestockItems > 0
                  ? Colors.green
                  : Colors.grey,
              foregroundColor: Colors.white,
              padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 15),
            ),
            icon: const Icon(Icons.check_circle),
            label: const Text(
              'POTVRDIT',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
            onPressed: totalRestockItems > 0 ? _submitRestock : null,
          ),
        ],
      ),
    );
  }
}
